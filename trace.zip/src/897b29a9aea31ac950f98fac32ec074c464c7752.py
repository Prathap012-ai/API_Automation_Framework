from pathlib import Path

from playwright.sync_api import expect


BASE_URL = "https://demowebshop.tricentis.com/"
PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS_DIR = PROJECT_ROOT / "reports"
SCREENSHOTS_DIR = REPORTS_DIR / "screenshots"
VIDEOS_DIR = REPORTS_DIR / "videos"


def _open_books(page):
    page.locator('a[href="/books"]').first.click()
    expect(page).to_have_url(f"{BASE_URL}books")
    expect(page.get_by_role("heading", name="Books", exact=True)).to_be_visible()


def _search_for_computer(page):
    page.locator("#small-searchterms").fill("computer")
    page.locator("input.search-box-button").click()
    expect(page.locator("h2.product-title a").first).to_be_visible()


def test_screenshots(page):
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)

    page.goto(BASE_URL, wait_until="domcontentloaded")
    expect(page).to_have_title("Demo Web Shop")
    page.screenshot(path=str(SCREENSHOTS_DIR / "homepage.png"))

    _open_books(page)
    page.screenshot(
        path=str(SCREENSHOTS_DIR / "books_full_page.png"),
        full_page=True,
    )


def test_video_recording(browser):
    VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
    context = browser.new_context(record_video_dir=str(VIDEOS_DIR))
    page = context.new_page()
    page.goto(BASE_URL, wait_until="domcontentloaded")
    _open_books(page)
    page.locator("#products-orderby").select_option(label="Name: A to Z")
    page.locator("#small-searchterms").fill("computer")
    page.locator("input.search-box-button").click()
    expect(page.locator("h2.product-title a").first).to_be_visible()

    video = page.video
    context.close()

    assert video is not None
    video_path = Path(video.path())
    assert video_path.is_file(), f"Expected a recorded video at {video_path}"
    assert video_path.stat().st_size > 0, "The recorded video is empty"


def test_playwright_trace(page):
    trace_path = PROJECT_ROOT / "trace.zip"
    page.context.tracing.start(screenshots=True, snapshots=True, sources=True)

    page.goto(BASE_URL, wait_until="domcontentloaded")
    _open_books(page)
    _search_for_computer(page)

    page.context.tracing.stop(path=str(trace_path))
    assert trace_path.is_file(), f"Expected a trace archive at {trace_path}"
    assert trace_path.stat().st_size > 0, "The trace archive is empty"


def test_screenshots_videos_and_traces_together(browser):
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    VIDEOS_DIR.mkdir(parents=True, exist_ok=True)
    context = browser.new_context(record_video_dir=str(VIDEOS_DIR))
    context.tracing.start(screenshots=True, snapshots=True, sources=True)
    page = context.new_page()

    page.goto(BASE_URL, wait_until="domcontentloaded")
    expect(page).to_have_title("Demo Web Shop")
    page.screenshot(path=str(SCREENSHOTS_DIR / "combined_homepage.png"))
    _open_books(page)
    page.screenshot(
        path=str(SCREENSHOTS_DIR / "combined_books_full_page.png"),
        full_page=True,
    )
    page.locator("#products-orderby").select_option(label="Name: A to Z")
    _search_for_computer(page)

    video = page.video
    trace_path = PROJECT_ROOT / "trace.zip"
    context.tracing.stop(path=str(trace_path))
    context.close()

    assert video is not None
    video_path = Path(video.path())
    assert video_path.is_file(), f"Expected a recorded video at {video_path}"
    assert video_path.stat().st_size > 0, "The recorded video is empty"
    assert trace_path.is_file(), f"Expected a trace archive at {trace_path}"
    assert trace_path.stat().st_size > 0, "The trace archive is empty"
